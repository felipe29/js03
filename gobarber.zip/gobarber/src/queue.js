import Queue from './lib/Queue';
import 'dotenv/config';

Queue.processQueue();
